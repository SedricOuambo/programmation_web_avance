import Connexion from "@/components/Connexion";
export default function Page() {
    return <>
        <Connexion />
    </>
}
import Contact from "@/components/Contact";
export default function Page() {
    return <>
        <Contact />
    </>
}
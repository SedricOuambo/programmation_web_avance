import Documents from "@/components/Documents";
export default function Page(){
    return <>
    <Documents/>
    </>
}
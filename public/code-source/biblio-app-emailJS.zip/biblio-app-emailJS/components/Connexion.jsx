
import FormNonControlle from "./FormNoncontrolle"
import FormControlle from "./FormControlle"
export default function Connexion() {
    return <>
    <div>Form Non controlle</div>
       <FormNonControlle/>
       <div>Form  controlle</div>
       <FormControlle/>
    </>
}
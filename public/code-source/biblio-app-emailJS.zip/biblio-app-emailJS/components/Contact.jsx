import FormHook from "./FormHook"
export default function Contact() {
    return <>
        <FormHook />
    </>
}
'use client'
import styes from './FormControlle.module.css'
import { useState } from 'react'

export default function FormControlle() {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('')

    const handleEmail = (event) =>  {setEmail(event.target.value)}
    const handlePassword = (event) => {setPassword(event.target.value)}

    const handleSubmit = (event) => {
        event.preventDefault();

    }

    return <>
        <form onSubmit={handleSubmit} className={styes.form}>
            <div>
                <label>
                    Email:
                    <input
                        type="text"
                        value={email}
                        onChange={handleEmail}
                    />
                </label>
            </div>
            <div>
                <label>
                    Password:
                    <input 
                    type="password" 
                    value={password}
                    onChange={handlePassword}/>
                </label>
            </div>
            <button type='submit'>Envoyer</button>
        </form>
    </>
}
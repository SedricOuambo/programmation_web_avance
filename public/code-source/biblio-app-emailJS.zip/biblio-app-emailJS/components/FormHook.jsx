'use client'
import styles from './FormHook.module.css'
import { useForm } from 'react-hook-form';
import { useState } from 'react';
import emailjs from "@emailjs/browser";

export default function FormHook() {
    const [result, setResult] = useState('');
    const [success, setSuccess] = useState(true);

    const {
        register, handleSubmit, getValues,
        formState: { errors }
    } = useForm({
        defaultValues: {
            nom: '',
            email: '',
            objet: '',
            message: ''
        }
    });

    const sendmail = () =>{
        const values = getValues();

        const templateParams = {
            name: values.nom,
            subject: values.objet,
            email: values.email,
            message: values.message,
        }

        emailjs.send(
            'service_e8l5qhh', //Service_ID
            'template_2gzcyss', //template_ID
            templateParams,
            'XI68Lm3ggbss3OTpx' //USER PUBLIC KEY
        ).then(
            (response) =>{
                setResult("message envoye avec succes");
                setSuccess(true);
            },
            (error) =>{
                setResult("message non envoye");
                setSuccess(false)
            }
        )
    }

    return <>
        <form className={styles.form} onSubmit={handleSubmit(sendmail)}>
            <div>
                <label>
                    Nom :
                    <input
                        type="text"
                        placeholder='votre nom'
                        {...register("nom",
                            {
                                required: 'Ce champ est obligatoire',
                            }
                        )
                        }
                    />
                </label>
                <div className={styles.erreur}>{errors.nom?.message}</div>
            </div>

            <div>
                <label>
                    Email:
                    <input
                        type="text"
                        placeholder='votre email'
                        {...register("email",
                            {
                                required: 'Ce champ est obligatoire',
                                pattern: {
                                    value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                    message: 'Email invalide'
                                }
                            }
                        )
                        }
                    />
                </label>
                <div className={styles.erreur}>{errors.email?.message}</div>
            </div>

            <div>
                <label>
                    Objet :
                    <input
                        type="text"
                        placeholder='objet du message'
                        {...register("objet",
                            {
                                required: 'Ce champ est obligatoire',
                            }
                        )
                        }
                    />
                </label>
                <div className={styles.erreur}>{errors.objet?.message}</div>
            </div>

            <div>
                <label>
                    Message :
                    <textarea
                        cols={20}
                        rows={10}
                        placeholder='votre message'
                        {...register("message",
                            {
                                required: 'Ce champ est obligatoire',
                            }
                        )
                        }
                    />
                </label>
                <div className={styles.erreur}>{errors.message?.message}</div>
            </div>

            <button type='submit'>Envoyer</button>
            <div className={success ? styles.result_OK : styles.result_NOT_OK}>{result}</div>
        </form>
    </>
}
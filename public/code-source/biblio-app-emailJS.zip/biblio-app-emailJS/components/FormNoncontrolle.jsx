'use client'
import styes from './FormNonControlle.module.css'
import { useRef, useState } from 'react'

export default function FormNonControlle(){
    const emailRef = useRef(null)
    const passwordRef = useRef(null)

    const [erreurEmail, setErreurEmail] = useState('');
    const [erreurPassword, setErreurPassword]= useState('')
    const [envoi, setEnvoi] = useState('')

    const handleSubmit = (event) =>{
        event.preventDefault();
        const email = emailRef.current.value;
        const password = passwordRef.current.value

        let erreur = false;

        if(!email){
            setErreurEmail("Ce champ doit être rempli")
            erreur = true;
        }
        else{
            setErreurEmail('')
        }

        if(!password){
            setErreurPassword("Ce champ doit être rempli")
            erreur = true;
        }
        else{
            setErreurPassword('')
        }

        if(erreur){
            setEnvoi('Message non envoye')
            return
        }

        setEnvoi('Message envoye')

        // console.log(`Email : ${email} et Password : ${password}`)
    }

    return<>
    <form onSubmit={handleSubmit}>
        <div>
            <label>
                Email:
                <input type="text" ref={emailRef}/>
                {erreurEmail && 
                <div className={styes.erreur}> {erreurEmail}</div>}
            </label>
        </div>
        <div>
            <label>
                Password:
                <input type="password" ref={passwordRef}/>
                {erreurPassword && 
                <div className={styes.erreur}> {erreurPassword}</div>}
            </label>
        </div>
        <button type='submit'>Envoyer</button>

        {envoi}
    </form>
    </>
}
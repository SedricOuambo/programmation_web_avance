import styles from './MenuNav.module.css';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
export default function MenuNav() {
    const pathname = usePathname()
    return <nav className={styles.nav}>
        <ul>
            <li><Link href="/"
                className={pathname === '/' ? styles.active : ''}
            >Accueil</Link></li>
            <li className={styles.active}><Link href="/documents"
                className={pathname === '/documents' ? styles.active : ''}
            >Documents</Link></li>
            <li><Link href="/contact"
                className={pathname === '/contact' ? styles.active : ''}
            >Contact</Link></li>
            <li><Link href="/connexion"
                className={pathname === '/connexion' ? styles.active : ''}
            >Connexion</Link></li>
        </ul>
    </nav>
}
import Image from "next/image";
import styles from "./page.module.css";
import Citation from "@/components/Citation";
export default function Home() {
  return (
    <main className={styles.main}>
      <Citation auteur='Sedric'>
        Nous y sommes
      </Citation>
      <div className={styles.welcome}>
        Soyez la bienvenue sur biblio-app
      </div>
    </main>
  );
}

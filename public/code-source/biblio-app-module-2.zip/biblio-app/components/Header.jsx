import styles from './Header.module.css';
import Image from 'next/image';
import logo from '@/public/react.webp';
export default function Header() {
    return <header className={styles.header}>
        <div className={styles.title}>
            <Image
                src={logo}
                alt="Logo React"
                width={80}
            />
            <h1>Titre du site web</h1>
        </div>
        <nav className={styles.nav}>
            <ul>
                <li><a href="#">Accueil</a></li>
                <li><a href="#">Documents</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">Connexion</a></li>
            </ul>
        </nav>
    </header>
}
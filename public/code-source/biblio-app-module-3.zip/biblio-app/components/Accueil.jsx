import styles from './Accueil.module.css';
import Citation from './Citation';

export default function Accueil() {
    return <>
        <Citation auteur='Sedric'>
            Nous y sommes
        </Citation>
        <div className={styles.welcome}>
            Soyez la bienvenue sur biblio-app
        </div>
    </>
}
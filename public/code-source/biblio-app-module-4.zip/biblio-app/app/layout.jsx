'use client'
import Documents from "@/components/Documents";
import Connexion from "@/components/Connexion";
import Contact from "@/components/Contact";
import { useState } from "react";
import Accueil from "@/components/Accueil";
import Header from '@/components/Header'
import { Inter } from "next/font/google";
import Footer from '@/components/Footer';
import "./globals.css";
import styles from './layout.module.css';
const inter = Inter({ subsets: ["latin"] });
export default function RootLayout({ children }) {
  const [page, setPage] = useState('accueil');
  return (
    <html lang="en">
      <body className={inter.className + ' ' + styles.body}>
        <Header setPage={setPage} />
        {/* {children} */}
        <main className={styles.main}>
          {page === 'accueil' ?
            <Accueil />
            : page === 'documents' ?
              <Documents />
              : page === 'contact' ?
                <Contact />
                : page === 'connexion' ?
                  <Connexion />
                  : <div>404 - Not Found</div>
          }

          {/* {page === 'accueil' && <Accueil />}
          {page === 'documents' && <Documents />}
          {page === 'contact' && <Contact />}
          {page === 'connexion' && <Connexion />} */}
        </main>
        <Footer />
      </body>
    </html>
  );
}

'use client'
import Accueil from "@/components/Accueil";
export default function Home() {
  return <>
    <Accueil />
  </>
}

import Link from 'next/link';
import styles from './MenuNav.module.css';
// import { useRouter } from 'next/navigation';
export default function MenuNav() {
    // const routeur = useRouter();
    return <nav className={styles.nav}>
        <ul>
            <li><Link href="/">Accueil</Link></li>
            <li><Link href="/documents">Documents</Link></li>
            <li><Link href="/contact">Contact</Link></li>
            <li><Link href="/connexion">Connexion</Link></li>
            
            {/* <li onClick={() => routeur.push('/')}>Accueil</li>
            <li onClick={() => routeur.push('/documents')}>Documents</li>
            <li onClick={() => routeur.push('/contact')}>Contact</li>
            <li onClick={() => routeur.push('/connexion')}>Connexion</li> */}
        </ul>
    </nav>
}
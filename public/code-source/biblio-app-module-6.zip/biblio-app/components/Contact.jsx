export default function Contact() {
    return <>
        <div>
            Contact
        </div>
    </>
}